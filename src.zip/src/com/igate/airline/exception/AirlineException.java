package com.igate.airline.exception;

public class AirlineException extends Exception{
	public AirlineException(String message)
	{
		super(message);
	}

}
